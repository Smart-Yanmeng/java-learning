import com.botao.dao.ManagerDao;
import com.botao.dao.impl.CartDaoImpl;
import com.botao.dao.impl.ManagerDaoImpl;
import com.botao.dao.impl.ProductDaoImpl;
import com.botao.dao.impl.UserDaoImpl;
import com.botao.pojo.Manager;
import com.botao.pojo.Order;
import com.botao.pojo.Product;
import com.botao.pojo.User;
import com.botao.service.impl.CartServiceImpl;
import com.botao.service.impl.OrderServiceImpl;
import com.botao.service.impl.ProductServiceImpl;
import com.botao.service.impl.UserServiceImpl;
import com.botao.utils.BaseDao;
import com.botao.utils.Helper;
import org.junit.Test;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.UUID;

public class Ts {

    @Test
    public void a() throws SQLException {
//        Connection connection = BaseDao.getConnection();
//        UserDaoImpl userDao = new UserDaoImpl();
//
//
//        User user = userDao.getUserById(connection, "05546b24af2f4d45a6f9c3570534de0f");
//
//        user.setName("广安职院");
//
//        int i = userDao.UpdateUserById(connection, user);
//
//        System.out.println(i);
//        Connection connection = BaseDao.getConnection();
//        UserDaoImpl userDao = new UserDaoImpl();
//        User user = userDao.getUserById(connection, "05546b24af2f4d45a6f9c3570534de0f");
//        UserServiceImpl userService = new UserServiceImpl();
//        user.setName("广安职业技术学院");
//        userService.UpdateUserById(user);

//        System.out.println("editpage".substring(0,8));

        //05546b24af2f4d45a6f9c3570534de0f
//
//        CartDaoImpl cartDao = new CartDaoImpl();
//        ProductDaoImpl productDao = new ProductDaoImpl();
//        Connection connection = BaseDao.getConnection();
//
//        List<String> cartsByUserId = cartDao.getCartsByUserId(connection, "05546b24af2f4d45a6f9c3570534de0f");
//        System.out.println(cartsByUserId.size());
//        for (String s : cartsByUserId) {
//
//            System.out.println(s);
//            Product productById = productDao.getProductById(connection, s);
//            System.out.println(productById.getDesc());
//        }
//
//
//        CartServiceImpl cartService = new CartServiceImpl();
//        List<Product> cartsByUserId = cartService.getCartsByUserId("05546b24af2f4d45a6f9c3570534de0f");
//        for (Product product : cartsByUserId) {
//            System.out.println(product.getName());
//        }

/*
        OrderServiceImpl orderService = new OrderServiceImpl();

        Order order = new Order();
        order.setUserid("123456789");
        order.setProductid("987654321");
        order.setNumber(0);
        order.setAddr("福建省三明市！");
        boolean b = orderService.addOrder(order);


        System.out.println(b);
*/


    }

}