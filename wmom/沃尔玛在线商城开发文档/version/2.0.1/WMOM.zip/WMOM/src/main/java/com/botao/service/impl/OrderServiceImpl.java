package com.botao.service.impl;

import com.botao.dao.OrderDao;
import com.botao.dao.impl.OrderDaoImpl;
import com.botao.pojo.Order;
import com.botao.service.OrderService;
import com.botao.utils.BaseDao;
import com.botao.utils.Helper;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class OrderServiceImpl implements OrderService {
    private OrderDao orderDao =new OrderDaoImpl();
    @Override
    public boolean addOrder(Order order) throws SQLException {
        Connection connection = BaseDao.getConnection();
        order.setId(Helper.getUUID());
        order.setStatus(0);
        order.setCreated(new Date(new java.util.Date().getTime()));
        int i = orderDao.addOrder(connection, order);
        return i!=0;
    }

    @Override
    public List<Order> getOrdersByUserId(String userId) throws SQLException {
        Connection connection = BaseDao.getConnection();
        List<Order> orders = orderDao.getOrdersByUserId(connection, userId);
        return orders;
    }
}
