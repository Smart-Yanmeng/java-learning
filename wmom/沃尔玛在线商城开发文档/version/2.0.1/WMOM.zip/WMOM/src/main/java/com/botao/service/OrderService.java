package com.botao.service;

import com.botao.pojo.Order;

import java.sql.SQLException;
import java.util.List;

public interface OrderService {

    /**
     * 订单创建
     * @param order
     * @return
     * @throws SQLException
     */
    public boolean addOrder(Order order) throws SQLException;


    public List<Order> getOrdersByUserId(String userId) throws SQLException;


}
