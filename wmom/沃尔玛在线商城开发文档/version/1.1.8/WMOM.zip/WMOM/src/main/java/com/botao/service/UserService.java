package com.botao.service;

import com.botao.pojo.User;

import java.sql.SQLException;

public interface UserService {
    /**
     * 用户注册
     * @param user 用户对象
     * @return bool
     */
    public Boolean addUser(User user) throws SQLException;


}
