package com.botao.dao;

import com.botao.pojo.User;

import java.sql.Connection;
import java.sql.SQLException;

public interface UserDao {
    /**
     * 用户添加
     * @param connection 连接对象
     * @param user 用户
     * @return
     */
    public int addUser(Connection connection , User user) throws SQLException;



}
