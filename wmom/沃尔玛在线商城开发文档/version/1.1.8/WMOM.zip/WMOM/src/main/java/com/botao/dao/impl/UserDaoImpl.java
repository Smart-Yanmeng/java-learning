package com.botao.dao.impl;

import com.botao.dao.UserDao;
import com.botao.pojo.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

public class UserDaoImpl implements UserDao {
    @Override
    public int addUser(Connection connection, User user) throws SQLException {
        String id = user.getId();
        String username = user.getUsername();
        String name = user.getName();
        String password = user.getPassword();
        String phone = user.getPhone();
        Integer status = user.getStatus();
        Date created = user.getCreated();
        PreparedStatement preparedStatement = connection.prepareStatement("insert into user (id, username, name, password, phone, status, created) value (?,?,?,?,?,?,?)");
        preparedStatement.setString(1, id);
        preparedStatement.setString(2, username);
        preparedStatement.setString(3, name);
        preparedStatement.setString(4, password);
        preparedStatement.setString(5, phone);
        preparedStatement.setInt(6, status);
        preparedStatement.setDate(7, new java.sql.Date(created.getTime()));
        return preparedStatement.executeUpdate();
    }
}
