package com.botao.service.impl;

import com.botao.dao.UserDao;
import com.botao.dao.impl.UserDaoImpl;
import com.botao.pojo.User;
import com.botao.service.UserService;
import com.botao.utils.BaseDao;
import com.botao.utils.Helper;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

public class UserServiceImpl implements UserService {
    private UserDao userDao = new UserDaoImpl();

    @Override
    public Boolean addUser(User user) throws SQLException {
        Connection connection = BaseDao.getConnection();
        user.setId(Helper.getUUID());
        user.setStatus(1);
        user.setCreated(new Date());
        int i = userDao.addUser(connection, user);
        return i == 1;
    }
}
