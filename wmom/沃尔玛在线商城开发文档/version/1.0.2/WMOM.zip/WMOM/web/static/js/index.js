function msTime(s) {
    return setInterval(function () {
        $("#ms-time").text(s--);
    }, 1000)
}

function tab() {
    $(".left-nav ul li").mouseenter(function () {
        console.log($(this).index());
        $("#c-one").hide();
        $(".nac").eq($(this).index()).addClass("c-active").siblings().removeClass("c-active");
    });

    $(".fs").mouseleave(lv);
    $(".right-self").mouseenter(lv);

    function lv() {
        $("#c-one").show();
        $(".nac").removeClass("c-active");
    }

}

function getProduct() {
    $.get("/api/product/queryall", function (data) {

        let products = data.data;
        console.log(products);
        let ml="";
        products.forEach((product) => {
            ml += `<div class="item">
        <div class="top-img">
            <img src="/upload/${product.img}"
                 alt="">
        </div>
        <div class="bottom">
            <h3 class="text-danger pb-0 mb-0">${product.price}</h3>
            <p>${product.desc}</p>
            <span class="mr-5 pr-2"></span>
            <a href="./product.jsp" class="btn btn-sm btn-outline-warning">LOOK</a>
            <a href="#" class="btn btn-sm btn-outline-danger">GWC</a>
        </div>
    </div>`
        })
        $(".commodity").append(ml);
    })
}

$(function () {
    msTime(500);
    tab();
    getProduct();
})