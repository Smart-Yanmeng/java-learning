import com.botao.dao.ManagerDao;
import com.botao.dao.impl.ManagerDaoImpl;
import com.botao.pojo.Manager;
import com.botao.utils.BaseDao;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

public class Ts {
    @Test
    public void a() throws SQLException {
        System.out.println(UUID.randomUUID().toString().replace("-",""));
        Connection connection = BaseDao.getConnection();

        Statement statement = connection.createStatement();

        ResultSet resultSet = statement.executeQuery("select * from manager");

        resultSet.next();

        System.out.println(resultSet.getString("username"));
    }

    @Test
    public void b() throws Exception {
        ManagerDao managerDao = new ManagerDaoImpl();

        Connection connection = BaseDao.getConnection();

//        Manager manager = managerDao.getManagerById(connection, "4931d94bd2ad4b359abfdc75538cb030");
//
//        System.out.println(manager.getName());

        Manager jl = managerDao.getManagerByUserName(connection, "adminaa");
        if(jl==null){
            System.out.println("查无此人！");
        }


    }

    @Test
    public void c(){
        String replace = UUID.randomUUID().toString().replace("-", "");

        System.out.println(replace);
    }



}
